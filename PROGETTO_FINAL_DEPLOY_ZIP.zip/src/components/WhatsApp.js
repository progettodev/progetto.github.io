export default function WhatsApp(){
return(<a className="whatsapp" href="https://wa.me/918484866196" target="_blank" rel="noreferrer">WhatsApp</a>);
}