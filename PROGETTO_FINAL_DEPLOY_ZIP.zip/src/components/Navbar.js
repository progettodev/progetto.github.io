export default function Navbar(){
return(<nav>
<a href="#/">Home</a>
<a href="#/about">About</a>
<a href="#/products">Products</a>
<a href="#/contact">Contact</a>
</nav>);
}