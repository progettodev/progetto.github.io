export default function Contact(){
return(<div className="container"><h2>Contact</h2><p>Email: progettosolution029@gmail.com</p><p>WhatsApp: +91 84848 66196</p></div>);
}