export default function Products(){
return(<div className="container"><h2>Products</h2><ul><li>Restaurant Billing App</li><li>Inventory Management System</li></ul></div>);
}