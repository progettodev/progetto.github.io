export default function About(){
return(<div className="container"><h2>About PROGETTO</h2><p>IT Solutions for modern businesses.</p></div>);
}