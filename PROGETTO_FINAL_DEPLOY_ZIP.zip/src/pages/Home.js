export default function Home(){
return(<div className="container"><h1>PROGETTO</h1><p>Designed With Intent</p></div>);
}