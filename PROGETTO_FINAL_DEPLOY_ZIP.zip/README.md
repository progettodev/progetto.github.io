PROGETTO IT Solutions Website

1. npm install
2. npm install react-router-dom gh-pages
3. Set homepage in package.json
4. npm run deploy
